public class Main {
    public static void main(String[] args) {

        PayPal paypal = new PayPal();
        Stripe stripe = new Stripe();

        // Create adapters
        PaymentProcessor paypalAdapter = new PayPalAdapter(paypal);
        PaymentProcessor stripeAdapter = new StripeAdapter(stripe);

        // Process payments using adapters
        double amount = 100.0;
        paypalAdapter.processPayment(amount);
        stripeAdapter.processPayment(amount);
    }
}
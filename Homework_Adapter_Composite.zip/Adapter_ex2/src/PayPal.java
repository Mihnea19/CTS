public class PayPal {
    public PayPal(){};

    public void sendPayment(double amount){
        System.out.println("Sending PayPal payment for $" + amount);
    }
}

public class Stripe {
    public Stripe(){};

    public void makePayment(double amount){
        System.out.println("making payment with this amount: "+amount);
    }
}

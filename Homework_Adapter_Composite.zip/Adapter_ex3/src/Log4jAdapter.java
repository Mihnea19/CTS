public class Log4jAdapter implements MyLogger{
    private final ThirdPartyLogger thirdPartyLogger;

    public Log4jAdapter(ThirdPartyLogger thirdPartyLogger) {
        this.thirdPartyLogger = thirdPartyLogger;
    }

    @Override
    public void logMessage(String message) {
        thirdPartyLogger.log(message);
    }
}

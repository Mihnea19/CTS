public class Log4jLogger implements ThirdPartyLogger{
    @Override
    public void log(String message) {
        System.out.println("Log4j: " + message);
    }
}

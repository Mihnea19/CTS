public class Main {
    public static void main(String[] args) {
        // Create an instance of Log4jLogger (Third-party logger)
        ThirdPartyLogger log4jLogger = new Log4jLogger();

        // Create an adapter for MyLogger
        MyLogger loggerAdapter = new Log4jAdapter(log4jLogger);

        // Use the adapter to log messages
        loggerAdapter.logMessage("Hello, world!");
    }
}
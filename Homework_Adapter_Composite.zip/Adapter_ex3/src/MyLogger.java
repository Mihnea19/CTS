public interface MyLogger {
    void logMessage(String message);
}

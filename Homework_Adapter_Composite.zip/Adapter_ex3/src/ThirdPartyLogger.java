public interface ThirdPartyLogger {
    void log(String message);
}

public class Button implements GUIComponent{
    @Override
    public void draw() {
        System.out.println("Drawing a button");
    }
}

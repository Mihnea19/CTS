public interface GUIComponent {
    void draw();
}

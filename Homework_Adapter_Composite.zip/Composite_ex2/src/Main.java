public class Main {
    public static void main(String[] args) {

        Panel panel = new Panel();

        Button button1 = new Button();
        Button button2 = new Button();

        panel.addComponent(button1);
        panel.addComponent(button2);

        panel.draw();  // This will draw the panel and all its components (buttons)

    }
}
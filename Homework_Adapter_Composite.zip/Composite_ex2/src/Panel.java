import java.util.ArrayList;
import java.util.List;

public class Panel implements GUIComponent{
    private List<GUIComponent> components=new ArrayList<>();

    public void addComponent(GUIComponent component){
        components.add(component);
    }

    @Override
    public void draw() {
        System.out.println("Drawing a panel");
        for (GUIComponent component : components) {
            component.draw();
        }
    }
}

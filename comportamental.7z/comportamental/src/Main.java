import observer.WheatherDisplay;
import observer.WheatherStation;

// Press Shift twice to open the Search Everywhere dialog and type `show whitespaces`,
// then press Enter. You can now see whitespace characters in your code.
public class Main {
    public static void main(String[] args) {
    //exemplul 1
        TextEditor editor=new TextEditor(new UppercaseFormatter());

        String text="ALO teaetaeta";
        System.out.println("Original text: " + text);
        System.out.println("Uppercase: " + editor.formatText(text));

        editor.setFormatter(new LowercaseFormatter());
        System.out.println("Lowercase: " + editor.formatText(text));

        editor.setFormatter(new CamelCaseFormatter());
        System.out.println("Camel case: "+editor.formatText(text));

        //exemplul 2 Observer
        WheatherStation wheatherStation=new WheatherStation();
        WheatherDisplay display1 =new WheatherDisplay();
        WheatherDisplay display2 = new WheatherDisplay();

        wheatherStation.registerObserver(display1);
        wheatherStation.registerObserver(display2);

        wheatherStation.setMeasurements(75, 22 ,44);
        wheatherStation.setMeasurements(44, 55, 66);

        //exemplul 3 State


    }
}
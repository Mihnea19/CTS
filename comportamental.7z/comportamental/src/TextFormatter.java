public interface TextFormatter {
    String format(String text);
}
